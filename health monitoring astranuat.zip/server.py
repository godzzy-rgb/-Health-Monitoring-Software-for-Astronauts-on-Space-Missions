#!/usr/bin/env python3
"""Astro Health Companion HTTP server. Standard library only.

API
  GET    /api/health
  GET    /api/crew
  GET    /api/indicators
  GET    /api/tasks
  GET    /api/summary?astronaut=A1
  GET    /api/history?astronaut=A1&indicator=sbp
  GET    /api/routine?astronaut=A1[&day=YYYY-MM-DD]
  GET    /api/export.csv?astronaut=A1
  POST   /api/log                  {"astronaut","indicator","value"}
  POST   /api/routine/complete     {"astronaut","task"}
  POST   /api/demo/seed            {"astronaut"}
  DELETE /api/readings/<id>?astronaut=A1

Configure with environment variables (see config.py). Run: python3 server.py
"""
import json
import logging
import mimetypes
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from config import Settings, load_settings
from db import Database
from guidance import INDICATORS
from tracker import Tracker, TASKS, ValidationError, NotFoundError

log = logging.getLogger("astro")

READING_PATH = re.compile(r"^/api/readings/(\d+)$")
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Content-Security-Policy": (
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; "
        "base-uri 'none'; form-action 'self'"
    ),
}


class PayloadTooLarge(Exception):
    pass


def load_crew(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def make_handler(tracker, crew, settings):
    frontend = os.path.realpath(settings.frontend_dir)

    class Handler(BaseHTTPRequestHandler):
        server_version = "AstroHealthCompanion/2.0"

        def log_message(self, fmt, *args):
            # Log method and path only. Never log query strings or bodies (health data).
            log.info("%s %s", self.command, urlparse(self.path).path)

        # ---------- responses ----------
        def _send(self, status, body, content_type, cache="no-store", headers=None):
            if isinstance(body, str):
                body = body.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            for k, v in SECURITY_HEADERS.items():
                self.send_header(k, v)
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def _json(self, status, payload):
            self._send(status, json.dumps(payload), "application/json; charset=utf-8")

        def _error(self, status, message):
            self._json(status, {"error": message})

        def _read_json(self):
            length = self.headers.get("Content-Length")
            if length is None:
                return {}
            try:
                n = int(length)
            except ValueError:
                raise ValidationError("invalid Content-Length")
            if n > settings.max_body_bytes:
                raise PayloadTooLarge()
            raw = self.rfile.read(n) if n else b""
            if not raw:
                return {}
            try:
                data = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                raise ValidationError("body must be valid JSON")
            if not isinstance(data, dict):
                raise ValidationError("body must be a JSON object")
            return data

        # ---------- routing ----------
        def do_GET(self):
            self._dispatch("GET")

        def do_HEAD(self):
            self._dispatch("GET")

        def do_POST(self):
            self._dispatch("POST")

        def do_DELETE(self):
            self._dispatch("DELETE")

        def do_PUT(self):
            self._dispatch("PUT")

        def do_PATCH(self):
            self._dispatch("PATCH")

        def _dispatch(self, method):
            url = urlparse(self.path)
            query = {k: v[0] for k, v in parse_qs(url.query).items()}
            try:
                if url.path == "/api" or url.path.startswith("/api/"):
                    return self._api(method, url.path, query)
                if method not in ("GET", "HEAD"):
                    return self._error(405, "method not allowed")
                return self._static(url.path)
            except ValidationError as e:
                return self._error(400, str(e))
            except NotFoundError as e:
                return self._error(404, str(e))
            except PayloadTooLarge:
                return self._error(413, "request body too large")
            except Exception:
                log.exception("unhandled error")
                return self._error(500, "internal server error")

        def _api(self, method, path, query):
            astro = query.get("astronaut", "")
            if method == "GET":
                if path == "/api/health":
                    return self._json(200, {"status": "ok"})
                if path == "/api/crew":
                    return self._json(200, crew)
                if path == "/api/indicators":
                    return self._json(200, INDICATORS)
                if path == "/api/tasks":
                    return self._json(200, TASKS)
                if path == "/api/summary":
                    return self._json(200, tracker.summary(astro))
                if path == "/api/history":
                    return self._json(200, tracker.history(astro, query.get("indicator", "")))
                if path == "/api/routine":
                    return self._json(200, tracker.routine(astro, query.get("day")))
                if path == "/api/export.csv":
                    body = tracker.export_csv(astro)  # validates astronaut before it is used in a header
                    return self._send(200, body, "text/csv; charset=utf-8", headers={
                        "Content-Disposition": f'attachment; filename="{astro}-health-log.csv"'})
            elif method == "POST":
                body = self._read_json()
                astro = body.get("astronaut", "")
                if path == "/api/log":
                    return self._json(200, tracker.log(astro, body.get("indicator", ""), body.get("value")))
                if path == "/api/routine/complete":
                    tracker.complete(astro, body.get("task", ""))
                    return self._json(200, tracker.routine(astro))
                if path == "/api/demo/seed":
                    tracker.seed_demo(astro)
                    return self._json(200, {"ok": True})
            elif method == "DELETE":
                m = READING_PATH.match(path)
                if m:
                    return self._json(200, tracker.delete_reading(astro, int(m.group(1))))
            return self._error(404, "no such endpoint")

        def _static(self, path):
            rel = "index.html" if path in ("", "/") else path.lstrip("/")
            full = os.path.realpath(os.path.join(frontend, rel))
            if not (full == frontend or full.startswith(frontend + os.sep)) or not os.path.isfile(full):
                return self._error(404, "not found")
            ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
                ctype += "; charset=utf-8"
            with open(full, "rb") as f:
                body = f.read()
            return self._send(200, body, ctype, cache="no-cache")

    return Handler


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def create_server(settings: Settings, tracker=None, crew=None):
    crew = load_crew(settings.crew_path) if crew is None else crew
    if tracker is None:
        tracker = Tracker(Database(settings.db_path), [c["id"] for c in crew])
    return Server((settings.host, settings.port), make_handler(tracker, crew, settings))


def main():
    settings = load_settings()
    logging.basicConfig(level=settings.log_level,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    server = create_server(settings)
    host, port = server.server_address[:2]
    log.info("Astro Health Companion listening on http://%s:%s (db: %s)", host, port, settings.db_path)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
